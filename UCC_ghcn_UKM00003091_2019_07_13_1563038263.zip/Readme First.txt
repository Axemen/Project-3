[README]
--------------------------------------------------------------------------------------
Your data download is provided as a ZIP archive that contains the following:
-This readme file (Text Format)
-Data Download in CSV (Comma Separated Values) Format

The spreadsheet file has a .CSV extension which may not be recognized by some operating systems as an Excel/OpenOffice Calc
file but it WILL STILL open properly by selecting Open from the File menu in either spreadsheet program. Save the .CSV file 
to your hard-drive then in Excel (or Calc) select Open from the File menu and browse to the file's location, it should open
normally.

For comments, suggestions or help with Utah Climate Center Datasets or Downloads
Visit: http://climate.usu.edu/feedback.php
